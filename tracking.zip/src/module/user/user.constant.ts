//'admin' | 'user' | 'faculty'
export const USER_ROLE = {
    user: 'user',
    admin: 'admin',
    superAdmin:'superAdmin'
  } as const;
  
  export const USER_ACCESSIBILITY={
    isProgress:'isProgress',
    blocked:'blocked'
  }  as const;
  